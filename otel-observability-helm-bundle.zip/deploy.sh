#!/bin/bash
set -e

# Namespaces
kubectl apply -f manifests/namespace.yaml

# Add Helm repos
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo add jaegertracing https://jaegertracing.github.io/helm-charts
helm repo add open-telemetry https://open-telemetry.github.io/opentelemetry-helm-charts
helm repo add elastic https://helm.elastic.co
helm repo add fluent https://fluent.github.io/helm-charts
helm repo update

# Prometheus
helm install prometheus prometheus-community/prometheus --namespace observability

# Grafana
helm install grafana grafana/grafana --namespace observability \
  --set adminPassword='admin' \
  --set service.type=LoadBalancer

# Jaeger
helm install jaeger jaegertracing/jaeger --namespace observability \
  --set provisionDataStore.cassandra=false \
  --set storage.type=elasticsearch

# OpenTelemetry Collector
helm install otel-collector open-telemetry/opentelemetry-collector \
  --namespace observability \
  -f values/otel-collector-values.yaml

# Elasticsearch
helm install elasticsearch elastic/elasticsearch --namespace observability

# Kibana
helm install kibana elastic/kibana --namespace observability \
  --set service.type=LoadBalancer

# Fluent Bit
helm install fluent-bit fluent/fluent-bit --namespace observability \
  --set backend.type=es \
  --set backend.es.host=elasticsearch-master \
  --set backend.es.port=9200

echo "✅ Deployment complete. Access Grafana, Kibana, and Jaeger via LoadBalancer IPs."
# Deploy frontend app
kubectl apply -f manifests/frontend-configmap.yaml
kubectl apply -f manifests/frontend.yaml